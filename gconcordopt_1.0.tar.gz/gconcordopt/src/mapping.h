
using Eigen::Map;
typedef Eigen::Map<Eigen::MatrixXd> MapMatd;
